<template>
  <div>
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/welcome' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>用户管理</el-breadcrumb-item>
      <el-breadcrumb-item>用户列表</el-breadcrumb-item>
    </el-breadcrumb>
    <el-card class="box-card">
      <el-row :gutter="20">
        <el-col :span="4"
          ><div class="grid-content bg-purple">
            <el-button type="primary">添加用户</el-button>
          </div>
        </el-col>
      </el-row>
      <el-card class="box-card">
        <el-table :data="rolesList" border style="width: 100%">
          <el-table-column type="expand" prop="more" label="更多" width="50">
            <div class="col-8-16">
              <el-col class="el-col-f" :span="8">
                <el-row class="row-f">
                  <el-tag>
                    {{rolesList}} <i class="el-icon-caret-right"></i>
                  </el-tag>
                </el-row>
              </el-col>
              <el-col class="el-col-f2" :span="16">
                <el-row class="el-row-aset">
                  <el-col :span="9"
                    ><el-tag type="success">
                      权限管理 <i class="el-icon-caret-right"></i> </el-tag
                  ></el-col>
                  <el-col :span="15"
                    ><el-tag
                      v-for="tag in rightList1"
                      :key="tag.id"
                      closable
                      :type="tag.type"
                    >
                      {{ tag.authName }}
                    </el-tag>
                  </el-col>
                </el-row>
                <el-row class="el-row-aset">
                  <el-col :span="9"
                    ><el-tag type="success">
                      权限管理 <i class="el-icon-caret-right"></i> </el-tag
                  ></el-col>
                  <el-col :span="15"
                    ><el-tag
                      v-for="tag in rightList1"
                      :key="tag.id"
                      closable
                      :type="tag.type"
                    >
                      {{ tag.authName }}
                    </el-tag>
                  </el-col>
                </el-row>
                <el-row class="el-row-aset">
                  <el-col :span="9"
                    ><el-tag type="success">
                      权限管理 <i class="el-icon-caret-right"></i> </el-tag
                  ></el-col>
                  <el-col :span="15"
                    ><el-tag
                      v-for="tag in goodsList"
                      :key="tag.goods_id"
                      closable
                      :type="tag.type"
                    >
                      {{ tag.goods_name }}
                    </el-tag>
                  </el-col>
                </el-row>
              </el-col>
            </div>
          </el-table-column>
          <el-table-column prop="id" label="序号" width="180">
          </el-table-column>
          <el-table-column prop="roleName" label="角色名称"></el-table-column>
          <el-table-column prop="roleDesc" label="角色描述"></el-table-column>
          <el-table-column label="操作">
            <template v-slot="scope1">
              <el-button
                size="small"
                type="primary"
                icon="el-icon-edit"
                @click="editFn(scope1)"
                >编辑</el-button
              >
              <el-button
                size="small"
                type="danger"
                icon="el-icon-delete"
                class="middle-btn"
                @click="delUserFn(scope1)"
                >删除</el-button
              >
              <el-button
                size="small"
                type="warning"
                icon="el-icon-setting"
                @click="setUserFn(scope1)"
                >分配权限</el-button
              >
            </template>
          </el-table-column>
        </el-table>
      </el-card>
    </el-card>
  </div>
</template>

<script>

import { getMenusApi, getRolesApi, getRightListApi } from '@/api/user'
import { getGoodsListApi } from '@/api/goods'
export default {
  name: 'roleslist',
  created () {
    this.getMenusApi()
    this.getRolesApi()
    this.getRightListApi()
    this.getGoodsListApi()
  },
  data () {
    return {
      tableData: [{
        more: 1,
        order: 1,
        roleName: 'yasuo',
        roleDescribe: 'hello'
      }],
      scope1: {},
      rightList: [],
      rightList1: [],
      rolesList: [],
      goodsList: [],
      pagenum: 1,
      pagesize: 8
    }
  },
  methods: {
    // 编辑
    editFn (scope1) {

    },
    // 删除
    delUserFn (scope1) {

    },
    // 分配权限
    setUserFn () {

    },
    //  左侧菜单权限
    async getMenusApi () {
      try {
        const res = await getMenusApi()
        console.log('menus', res)
      } catch (err) {
        console.log(err)
      }
    },
    // 角色列表
    async getRolesApi () {
      try {
        const res = await getRolesApi()
        this.rolesList = res.data.data
        console.log('获取角色列表', res, this.rolesList)
      } catch (err) {
        console.log(err)
      }
    },
    // 所有权限列表
    async getRightListApi () {
      try {
        const res = await getRightListApi('list')
        const res1 = await getRightListApi('tree')
        this.rightList = res.data.data
        this.rightList1 = res1.data.data
        console.log('rightlist', res, res1)
      } catch (err) {
        console.log(err)
      }
    },
    // 商品列表
    async getGoodsListApi () {
      try {
        const res = await getGoodsListApi({ pagenum: this.pagenum, pagesize: this.pagesize })
        this.goodsList = res.data.data.goods
        console.log('商品列表', res, this.GoodsList)
      } catch (err) {
        console.log(err)
      }
    }
  },
  computed: {},
  watch: {},
  filters: {},
  components: {}
}
</script>

<style scoped lang='less'>
.el-card {
  margin: 15px 0;
}
.el-col-f {
  display: flex;
  align-items: center;
  padding-left: 10px;
}
.el-tag {
  margin-right: 8px;
  margin-bottom: 10px;
}
.el-row-aset {
  display: flex;
  align-items: center;
  border-bottom: 1px solid #eeeeee;
  padding-top: 10px;
}
.col-8-16 {
  display: flex;
  .el-col-f {
    flex: 1;
    display: flex;
    align-items: center;
  }
  .el-col-f2 {
    flex: 2;
  }
}
</style>
